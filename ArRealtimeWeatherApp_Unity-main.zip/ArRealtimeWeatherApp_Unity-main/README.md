# ArCoreWeatherApp
 An Ar core Weather app , Uses Image tracking and weatherapi to get weather Data for the Current location .
 a convert function to convert the temperature between celcius and farenheit.
 Updated to also show the image of the current weather on the phone screen

 Made as a task for an interview.
 The phone model is not mine and its used for non commercial purposes
 all essential game elements in - ArCoreWeatherApp\Assets\Scenes
 
 the tracker image is in the same directory too

 Visit - https://anshurw.wixsite.com/abrport   for more details and drive link for video 
 
 twitter-@AbhiRwDev

 made by Abhishek Rawat
